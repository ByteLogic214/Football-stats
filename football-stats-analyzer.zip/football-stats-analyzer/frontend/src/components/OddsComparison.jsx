import React from 'react';

export default function OddsComparison({ odds }) {
  if (!odds || odds.length === 0) {
    return <p style={{ color: '#64748b', fontSize: '14px' }}>Sin cuotas disponibles para este partido</p>;
  }

  const markets = [...new Set(odds.map(o => o.market))];

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
      {markets.map(market => {
        const marketOdds = odds.filter(o => o.market === market);
        return (
          <div key={market} style={{ background: '#0f172a', padding: '15px', borderRadius: '8px', border: '1px solid #334155' }}>
            <h4 style={{ color: '#38bdf8', marginBottom: '10px', fontSize: '14px', fontWeight: 'bold' }}>{market}</h4>
            <div style={{ overflowX: 'auto' }}>
              <table style={{ width: '100%', fontSize: '13px' }}>
                <thead>
                  <tr>
                    <th style={{ textAlign: 'left', color: '#94a3b8', padding: '6px', borderBottom: '1px solid #334155' }}>Casa</th>
                    <th style={{ textAlign: 'left', color: '#94a3b8', padding: '6px', borderBottom: '1px solid #334155' }}>Selección</th>
                    <th style={{ textAlign: 'center', color: '#94a3b8', padding: '6px', borderBottom: '1px solid #334155' }}>Apertura</th>
                    <th style={{ textAlign: 'center', color: '#94a3b8', padding: '6px', borderBottom: '1px solid #334155' }}>Actual</th>
                    <th style={{ textAlign: 'center', color: '#94a3b8', padding: '6px', borderBottom: '1px solid #334155' }}>Prob. Implícita</th>
                  </tr>
                </thead>
                <tbody>
                  {marketOdds.map((o, i) => (
                    <tr key={i} style={{ borderBottom: '1px solid #1e293b' }}>
                      <td style={{ padding: '8px 6px', color: '#cbd5e1', fontWeight: '500' }}>{o.bookmaker}</td>
                      <td style={{ padding: '8px 6px', color: '#e2e8f0' }}>{o.selection}</td>
                      <td style={{ padding: '8px 6px', textAlign: 'center', color: '#94a3b8' }}>{o.opening ?? '-'}</td>
                      <td style={{ padding: '8px 6px', textAlign: 'center', color: '#22c55e', fontWeight: 'bold' }}>
                        {o.current ?? '-'}
                      </td>
                      <td style={{ padding: '8px 6px', textAlign: 'center', color: '#f59e0b', fontWeight: 'bold' }}>
                        {o.implied_prob ? `${o.implied_prob}%` : '-'}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        );
      })}
    </div>
  );
}
