import React from 'react';

export default function StatsTable({ stats }) {
  if (!stats || stats.length === 0) {
    return <p style={{ color: '#64748b', fontSize: '14px' }}>Sin estadísticas disponibles</p>;
  }

  return (
    <div style={{ overflowX: 'auto' }}>
      <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '14px' }}>
        <thead>
          <tr style={{ background: '#0f172a' }}>
            <th style={{ padding: '10px', textAlign: 'left', color: '#94a3b8', borderBottom: '2px solid #334155' }}>Estadística</th>
            <th style={{ padding: '10px', textAlign: 'center', color: '#38bdf8', borderBottom: '2px solid #334155' }}>Local</th>
            <th style={{ padding: '10px', textAlign: 'center', color: '#f472b6', borderBottom: '2px solid #334155' }}>Visitante</th>
            <th style={{ padding: '10px', textAlign: 'center', color: '#22c55e', borderBottom: '2px solid #334155' }}>Total</th>
          </tr>
        </thead>
        <tbody>
          {stats.map((s, i) => (
            <tr key={i} style={{ borderBottom: '1px solid #334155', background: i % 2 === 0 ? '#1e293b' : '#162032' }}>
              <td style={{ padding: '10px', color: '#e2e8f0', fontWeight: '500' }}>{s.label}</td>
              <td style={{ padding: '10px', textAlign: 'center', color: '#38bdf8', fontWeight: 'bold' }}>
                {s.home !== null && s.home !== undefined ? s.home : '-'}
              </td>
              <td style={{ padding: '10px', textAlign: 'center', color: '#f472b6', fontWeight: 'bold' }}>
                {s.away !== null && s.away !== undefined ? s.away : '-'}
              </td>
              <td style={{ padding: '10px', textAlign: 'center', color: '#22c55e' }}>
                {s.total !== null && s.total !== undefined ? s.total : '-'}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
