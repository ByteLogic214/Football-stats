import React from 'react';
import StatsTable from './StatsTable.jsx';
import OddsComparison from './OddsComparison.jsx';

export default function AnalysisDashboard({ analysis }) {
  return (
    <div style={{ background: '#1e293b', padding: '20px', borderRadius: '12px', border: '1px solid #334155' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '15px' }}>
        <h2 style={{ color: '#38bdf8', fontSize: '20px' }}>
          {analysis.home_team} <span style={{ color: '#64748b' }}>vs</span> {analysis.away_team}
        </h2>
        <span style={{ 
          background: analysis.status === 'live' ? '#dc2626' : '#059669',
          color: 'white',
          padding: '4px 12px',
          borderRadius: '12px',
          fontSize: '12px',
          fontWeight: 'bold'
        }}>
          {analysis.status === 'live' ? '🔴 EN VIVO' : '✅ FINALIZADO'}
        </span>
      </div>

      {analysis.score && (
        <div style={{ 
          fontSize: '28px', 
          fontWeight: 'bold', 
          color: '#22c55e', 
          marginBottom: '20px',
          textAlign: 'center',
          background: '#0f172a',
          padding: '15px',
          borderRadius: '8px'
        }}>
          {analysis.score.home} - {analysis.score.away}
        </div>
      )}

      <div style={{ marginBottom: '20px' }}>
        <h3 style={{ color: '#cbd5e1', marginBottom: '10px', fontSize: '16px' }}>📊 Estadísticas Clave</h3>
        <StatsTable stats={analysis.key_stats} />
      </div>

      <div style={{ marginBottom: '20px' }}>
        <h3 style={{ color: '#cbd5e1', marginBottom: '10px', fontSize: '16px' }}>🎯 Probabilidades Calculadas (Sin Vig)</h3>
        <div style={{ display: 'flex', gap: '15px' }}>
          {analysis.btts_probability && (
            <div style={{ background: '#0f172a', padding: '15px', borderRadius: '8px', flex: 1, textAlign: 'center' }}>
              <div style={{ fontSize: '12px', color: '#94a3b8', marginBottom: '5px' }}>Ambos Anotan (BTTS)</div>
              <div style={{ fontSize: '24px', fontWeight: 'bold', color: '#f59e0b' }}>
                {analysis.btts_probability}%
              </div>
            </div>
          )}
          {analysis.over_goals_probability && (
            <div style={{ background: '#0f172a', padding: '15px', borderRadius: '8px', flex: 1, textAlign: 'center' }}>
              <div style={{ fontSize: '12px', color: '#94a3b8', marginBottom: '5px' }}>Over 2.5 Goles</div>
              <div style={{ fontSize: '24px', fontWeight: 'bold', color: '#f59e0b' }}>
                {analysis.over_goals_probability}%
              </div>
            </div>
          )}
        </div>
      </div>

      <div>
        <h3 style={{ color: '#cbd5e1', marginBottom: '10px', fontSize: '16px' }}>💰 Comparación de Cuotas por Casa</h3>
        <OddsComparison odds={analysis.odds_comparison} />
      </div>
    </div>
  );
}
