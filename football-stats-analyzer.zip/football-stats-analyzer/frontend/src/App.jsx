import React, { useState, useEffect } from 'react';
import api from './services/api.js';
import AnalysisDashboard from './components/AnalysisDashboard.jsx';

function App() {
  const [matches, setMatches] = useState([]);
  const [selectedMatch, setSelectedMatch] = useState(null);
  const [analysis, setAnalysis] = useState(null);
  const [loading, setLoading] = useState(false);
  const [apiStatus, setApiStatus] = useState(null);

  useEffect(() => {
    checkHealth();
    loadMatches();
  }, []);

  const checkHealth = async () => {
    try {
      const data = await api.getHealth();
      setApiStatus(data);
    } catch (e) {
      setApiStatus({ status: 'error', error: e.message });
    }
  };

  const loadMatches = async () => {
    const data = await api.getMatches('?status=live,finished&per_page=20');
    setMatches(data.data || []);
  };

  const analyze = async (matchId) => {
    setLoading(true);
    setSelectedMatch(matchId);
    const data = await api.getAnalysis(matchId);
    setAnalysis(data);
    setLoading(false);
  };

  return (
    <div style={{ padding: '20px', maxWidth: '1200px', margin: '0 auto', minHeight: '100vh' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '8px' }}>
        <span style={{ fontSize: '32px' }}>⚽</span>
        <h1 style={{ color: '#38bdf8', fontSize: '28px' }}>Football Stats Analyzer</h1>
      </div>
      <p style={{ color: '#94a3b8', marginBottom: '20px', fontSize: '14px' }}>
        Datos reales de TheStatsAPI + Comparación de cuotas en tiempo real
      </p>

      {apiStatus && (
        <div style={{ 
          background: apiStatus.api_connected ? '#064e3b' : '#7f1d1d', 
          padding: '10px 15px', 
          borderRadius: '8px', 
          marginBottom: '20px',
          fontSize: '13px'
        }}>
          <strong>API Status:</strong> {apiStatus.api_connected ? '✅ Conectado a TheStatsAPI' : '❌ Desconectado'} 
          {apiStatus.error && ` - ${apiStatus.error}`}
        </div>
      )}

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 2fr', gap: '20px' }}>
        <div>
          <h3 style={{ color: '#cbd5e1', marginBottom: '10px', fontSize: '16px' }}>📋 Partidos</h3>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', marginTop: '10px' }}>
            {matches.length === 0 && (
              <p style={{ color: '#64748b', fontSize: '14px' }}>Cargando partidos reales...</p>
            )}
            {matches.map(m => (
              <button
                key={m.id}
                onClick={() => analyze(m.id)}
                style={{
                  padding: '12px',
                  background: selectedMatch === m.id ? '#0ea5e9' : '#1e293b',
                  border: '1px solid #334155',
                  borderRadius: '8px',
                  color: 'white',
                  cursor: 'pointer',
                  textAlign: 'left',
                  transition: 'all 0.2s'
                }}
              >
                <div style={{ fontWeight: 'bold', fontSize: '14px' }}>{m.home_team.name} vs {m.away_team.name}</div>
                <div style={{ fontSize: '12px', color: '#94a3b8', marginTop: '4px' }}>
                  {m.status === 'live' ? '🔴 EN VIVO' : '✅ Finalizado'} | 
                  Score: {m.score?.home ?? '-'} - {m.score?.away ?? '-'} | 
                  {m.odds_available ? '💰 Odds' : ''}
                </div>
              </button>
            ))}
          </div>
        </div>

        <div>
          {loading && (
            <div style={{ background: '#1e293b', padding: '40px', borderRadius: '12px', textAlign: 'center' }}>
              <div style={{ color: '#38bdf8', fontSize: '18px' }}>⏳ Cargando análisis con datos reales...</div>
            </div>
          )}
          {analysis && !loading && <AnalysisDashboard analysis={analysis} />}
          {!analysis && !loading && (
            <div style={{ background: '#1e293b', padding: '40px', borderRadius: '12px', textAlign: 'center', color: '#64748b' }}>
              Selecciona un partido para ver el análisis completo con estadísticas y cuotas
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default App;
