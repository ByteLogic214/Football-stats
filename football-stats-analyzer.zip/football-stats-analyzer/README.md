# ⚽ Football Stats Analyzer

Análisis avanzado de estadísticas de fútbol en tiempo real con comparación de cuotas de casas de apuestas. **Datos 100% reales** vía TheStatsAPI.

## 🚀 Stack Tecnológico
- **Backend:** FastAPI + Python 3.11 + httpx
- **Frontend:** React 18 + Vite
- **Datos:** TheStatsAPI (estadísticas reales + odds en vivo de múltiples bookmakers)
- **CI/CD:** GitHub Actions (build, test, deploy automático)
- **Deploy:** Docker + GitHub Container Registry

## 📊 Métricas Analizadas (Datos Reales)
| Estadística | Fuente |
|-------------|--------|
| **Corners** | Match Stats API |
| **Remates (totales / al arco / fuera)** | Match Stats API |
| **Goles + xG** | Match Stats + Shotmap API |
| **Tarjetas (amarillas/rojas)** | Match Stats + Timeline API |
| **Ambos Anotan (BTTS)** | Odds API + cálculo propio |
| **Posesión, Pases, Entradas** | Match Stats API |
| **Cuotas 1X2, Over/Under, Corners, AH** | Odds API (Pinnacle, Bet365, etc.) |

## 🔧 Configuración desde Móvil (sin terminal)

### 1. Crear repo en GitHub
- GitHub Mobile → `+` → New Repository
- Nombre: `football-stats-analyzer`

### 2. Subir archivos
- Ve a github.com en tu navegador móvil
- Usa **Add file** → **Upload files** para subir todo el contenido
- O usa **GitHub Desktop** si tienes acceso a PC brevemente

### 3. Configurar Secret (API Key)
1. Settings → Secrets and variables → Actions
2. New repository secret
3. Name: `THESTATSAPI_KEY`
4. Value: Tu API key de [thestatsapi.com](https://thestatsapi.com) (registro + trial 7 días gratis)

### 4. Activar GitHub Actions
- Pestaña Actions → Enable Actions
- Los workflows se ejecutan automáticamente en cada push a `main`

### 5. Deploy
- Las imágenes Docker se publican en `ghcr.io/tu-usuario/football-stats-analyzer`
- Conecta Render/Railway/Fly.io para deploy automático

## 🏃 Ejecución local
```bash
docker-compose up --build
```
Backend: http://localhost:8000/api/docs
Frontend: http://localhost

## ⚠️ Datos Reales Únicamente
Esta aplicación consume exclusivamente la API REST de TheStatsAPI. No hay mocks, simulaciones ni datos ficticios. Requiere API key válida.
