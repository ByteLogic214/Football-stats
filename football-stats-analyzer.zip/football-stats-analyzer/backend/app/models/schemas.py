from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any
from datetime import datetime

# ========== COMPETITIONS ==========
class Competition(BaseModel):
    id: str
    name: str
    country: Optional[str] = None
    country_code: Optional[str] = None
    type: str
    has_team_stats: bool
    has_player_stats: bool
    odds_available: bool = False
    live_odds_available: bool = False
    xg_available: bool = False

class CompetitionsResponse(BaseModel):
    data: List[Competition]
    meta: Dict[str, Any]

# ========== MATCHES ==========
class TeamRef(BaseModel):
    id: str
    name: str

class Score(BaseModel):
    home: Optional[int] = None
    away: Optional[int] = None

class Match(BaseModel):
    id: str
    competition_id: str
    season_id: str
    matchday: Optional[int] = None
    status: str
    utc_date: datetime
    home_team: TeamRef
    away_team: TeamRef
    score: Score
    odds_available: bool = False
    live_odds_available: bool = False
    xg_available: bool = False

class MatchesResponse(BaseModel):
    data: List[Match]
    meta: Dict[str, Any]

# ========== MATCH STATS ==========
class StatValue(BaseModel):
    home: Optional[float] = None
    away: Optional[float] = None

class MatchStatItem(BaseModel):
    all: Optional[StatValue] = None
    first_half: Optional[StatValue] = None
    second_half: Optional[StatValue] = None

class MatchStats(BaseModel):
    match_id: str
    overview: Dict[str, MatchStatItem]
    shots: Optional[Dict[str, MatchStatItem]] = None
    attack: Optional[Dict[str, MatchStatItem]] = None
    passes: Optional[Dict[str, MatchStatItem]] = None
    duels: Optional[Dict[str, MatchStatItem]] = None
    defending: Optional[Dict[str, MatchStatItem]] = None
    goalkeeping: Optional[Dict[str, MatchStatItem]] = None
    np_expected_goals: Optional[MatchStatItem] = None

# ========== ODDS ==========
class OddsValue(BaseModel):
    opening: Optional[str] = None
    last_seen: Optional[str] = None

class OverUnderOdds(BaseModel):
    over: Optional[OddsValue] = None
    under: Optional[OddsValue] = None

class MatchOddsMarkets(BaseModel):
    match_odds: Optional[Dict[str, OddsValue]] = None
    btts: Optional[Dict[str, OddsValue]] = None
    total_goals: Optional[Dict[str, OverUnderOdds]] = None
    match_corners: Optional[Dict[str, OverUnderOdds]] = None
    asian_handicap: Optional[Dict[str, Dict[str, OddsValue]]] = None

class BookmakerMatchOdds(BaseModel):
    bookmaker: str
    markets: MatchOddsMarkets

class MatchOdds(BaseModel):
    match_id: str
    bookmakers: List[BookmakerMatchOdds]

# ========== ANALYSIS ==========
class KeyStat(BaseModel):
    label: str
    home: Optional[float] = None
    away: Optional[float] = None
    total: Optional[float] = None

class OddsComparison(BaseModel):
    market: str
    bookmaker: str
    selection: str
    opening: Optional[str] = None
    current: Optional[str] = None
    implied_prob: Optional[float] = None

class MatchAnalysis(BaseModel):
    match_id: str
    home_team: str
    away_team: str
    status: str
    score: Optional[Score] = None
    key_stats: List[KeyStat]
    odds_comparison: List[OddsComparison]
    btts_probability: Optional[float] = None
    over_goals_probability: Optional[float] = None
    generated_at: datetime = Field(default_factory=datetime.utcnow)
