from fastapi import APIRouter
from app.api import competitions, matches, stats, odds, analysis

api_router = APIRouter()
api_router.include_router(competitions.router, prefix="/competitions", tags=["competitions"])
api_router.include_router(matches.router, prefix="/matches", tags=["matches"])
api_router.include_router(stats.router, prefix="/matches", tags=["stats"])
api_router.include_router(odds.router, prefix="/matches", tags=["odds"])
api_router.include_router(analysis.router, prefix="/analysis", tags=["analysis"])
